#include <stdio.h>
int main () {
    printf("##############################\n");
    printf("#                            #\n");
    printf("#       Hamka Arifani        #\n");
    printf("#       2410817110006        #\n");
    printf("#                            #\n");
    printf("##############################\n");
    return 0;
}