#include <stdio.h>
int main() {
    printf("Saya Calon Programmer No.1"); 
    return 0;
}