#include <stdio.h>
int main () {
    printf ("Andi Berkata \"Saya Pasti Bisa\"");
    return 0;
}