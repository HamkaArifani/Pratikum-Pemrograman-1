#include <stdio.h>
int main() {
    printf("Selamat Pagi, Hamka Arifani,\nSelamat Siang, Hamka Arifani,\nSelamat Malam, Hamka Arifani");
    return 0;   
}