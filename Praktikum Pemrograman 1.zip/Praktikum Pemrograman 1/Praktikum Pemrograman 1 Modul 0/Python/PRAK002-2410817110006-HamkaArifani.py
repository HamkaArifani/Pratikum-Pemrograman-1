print ("Selamat Pagi, Hamka Arifani");
print ("Selamat Siang, Hamka Arifani");
print ("Selamat Malam, Hamka Arifani");