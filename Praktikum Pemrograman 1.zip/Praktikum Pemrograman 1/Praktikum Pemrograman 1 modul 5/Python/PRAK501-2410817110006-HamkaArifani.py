def MaxBilangan(a:int, b:int, c:int,  d:int):
    return max(a, b, c, d)
a,b,c,d=map(int,input("").split())
hasil=max(a,b,c,d)
print(hasil)