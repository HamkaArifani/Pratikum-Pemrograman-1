#include <stdio.h>
int main () {
    int Hero, Pasukan, Bagi;
    Hero=5;
    Pasukan=958730;
    Bagi=Pasukan/Hero;
    printf("Jumlah pasukan yang dibawa Yu Zhong = 958730\n");
    printf("Jumlah pahlawan = 5\n");
    printf("Jumlah pasukan yang harus dikalahkan setiap pahlawan adalah %d pasukan",Bagi);
    return 0;
}