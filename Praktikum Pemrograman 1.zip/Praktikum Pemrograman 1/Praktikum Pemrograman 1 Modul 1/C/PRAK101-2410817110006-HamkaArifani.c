#include <stdio.h>
int main () {
    int Bilangan1, Bilangan2, Bilangan3, Hasil;
    printf("Variabel x bernilai ");
    scanf("%d", &Bilangan1);
    printf("Variabel y bernilai ");
    scanf("%d", &Bilangan2);
    printf("Variabel z bernilai ");
    scanf("%d", &Bilangan3);
    Hasil=Bilangan1+Bilangan2+Bilangan3;
    printf("Jumlah variabel tersebut adalah  %d", Hasil);
    return 0;
}