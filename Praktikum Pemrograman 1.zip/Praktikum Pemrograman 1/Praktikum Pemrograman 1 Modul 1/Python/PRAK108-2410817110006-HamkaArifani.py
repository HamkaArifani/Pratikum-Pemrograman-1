Tempuh=14;
Sebanyak=5;
keliling=Tempuh/Sebanyak;
phi=3.14;
jari2=float(keliling/(2*phi));
print("Diketahui :");
print("Pak Dengklek mengelilingi taman =  5 putaran");
print("Jarak tempuh Pak Dengklek =")
print("\nJawaban :");
print(f"Jari-jari taman yang dikelilingi Pak Dengklek adalah {jari2:.2f} Kilometer");