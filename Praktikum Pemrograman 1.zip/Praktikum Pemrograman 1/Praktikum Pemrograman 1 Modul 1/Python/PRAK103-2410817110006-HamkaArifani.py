Variabela=float(input("Variabel a bernilai "));
Variabelb=float(input("Variabel b bernilai "));
Variabelx=float(input("Variabel x bernilai "));
Variabely=float(input("Variabel y bernilai "));
AB=Variabela+Variabelb;
Hasil=Variabelx/Variabely*AB;
print(f" Hasil dari a ditambah b  dikali x dan dibagi y adalah {Hasil:.2f}");