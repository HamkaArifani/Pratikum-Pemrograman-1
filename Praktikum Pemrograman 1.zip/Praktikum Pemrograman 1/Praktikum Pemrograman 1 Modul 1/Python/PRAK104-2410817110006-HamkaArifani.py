SepatuA=float(input("Harga sepatu A adalah " ));
SepatuB=float(input("Harga sepatu B adalah " ));
DiskonA=round(SepatuA-SepatuA*0.13);
DiskonB=round(SepatuB-SepatuB*0.21);
print("Sepatu A mendapat diskon 13% sehingga harganya menjadi  ", DiskonA);
print("Sepatu B mendapat diskon 21% sehingga harganya menjadi  ", DiskonB);