Hero=5;
PasukanYZ=958730
Bagi=PasukanYZ/Hero;
print("Jumlah pasukan yang dibawa Yu Zhong = 958730");
print("Jumlah pahlawan = 5");
print(f"Jumlah pasukan yang harus dihadapi adalah {Bagi:.0f} Pasukan");