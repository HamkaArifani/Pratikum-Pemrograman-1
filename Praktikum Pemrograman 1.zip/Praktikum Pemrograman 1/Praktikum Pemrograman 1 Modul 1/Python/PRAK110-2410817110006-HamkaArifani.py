import math
Alas=5;
C=Alas;
Tinggi=12;
A=Tinggi;
B=math.sqrt(A*A+C*C)
Keliling=A+B+C;
Luas=Alas*Tinggi/2;
print(f"Diketahui :\nAlas = 5 cm\n Tinggi=12 cm\n\nJawab :\nSisi A = 12 cm\nSisi B = {B:.0f} cm");
print(f"Sisi C = 5 cm\nKeliling = {Keliling:.0f} cm\nLuas = {Luas:.0f} cm");