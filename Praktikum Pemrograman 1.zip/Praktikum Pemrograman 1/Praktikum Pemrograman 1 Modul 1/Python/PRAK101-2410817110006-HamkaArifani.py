Variabelx=int(input("Variabel x bernilai "));
Variabely=int(input("Variabel y bernilai "));
Variabelz=int(input("Variabel z bernilai "));
Hasil= Variabelx + Variabely +Variabelz;
print("Jumlah variabel tersebut adalah ", Hasil);