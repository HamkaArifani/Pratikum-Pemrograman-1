Variabelx=int(input("Variabel x bernilai "));
Variabely=int(input("Variabel y bernilai "));
Variabelz=int(input("Variabel z bernilai "));