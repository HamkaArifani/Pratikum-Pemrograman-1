Variabela=float(input("Variabel a bernilai "));
Variabelb=float(input("Variabel b bernilai "));
Variabelc=float(input("Variabel c bernilai "));
Hasil= Variabela*Variabelb/Variabelc
print(f" Hasil dari a dikali b dibagi c adalah {Hasil:.6f} ",);