Variabela=int(input("Variabel a bernilai "));
Variabelb=int(input("Variabel b bernilai "));
Variabelx=int(input("Variabel x bernilai "));
Variabely=int(input("Variabel y bernilai "));
AB=Variabela%Variabelb;
Hasil= Variabelx%Variabely+AB;
print(" Total sisa bagi dari a dibagi b  dan x  dibagi y adalah ", Hasil);