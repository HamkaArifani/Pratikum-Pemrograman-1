a=int(input("variabel a bernilai "));
b=int(input("variabel b bernilai "));
c=int(input("variabel a bernilai "));
if(a!=b): print("apakah variabel a sama dengan b ? jawabannya adalah 0");
if(b>c): print("apakah variabel b lebih besar dari c ? jawabannya adalah 1");
if(a!=c): print("apakah variabel a tidak sama dengan c ? jawabannya adalah 1");