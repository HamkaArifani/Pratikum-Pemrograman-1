sisi1=4;
sisi2=5;
sisi3=7;
Harga=85000
Keliling=sisi1+sisi2+sisi3;
Total=Keliling*Harga;
print("Diketahui :");
print("Panjang sisi segitiga berturut-turut adalah 4, 5, dan 7")
print("Keliling Tanah Pak Dengklek adalah ", Keliling)
print("tanah Per Meter adalah 85000")
print("Jawaban :")
print("Biaya yang diperlukan Pak Dengklek adalah Rp : ", Total)