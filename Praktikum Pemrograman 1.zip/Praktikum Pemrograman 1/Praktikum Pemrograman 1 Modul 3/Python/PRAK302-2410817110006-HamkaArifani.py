Nilai=int(input("Silahkan masukkan nilai: "))
if 80<= Nilai <=100:
    print("Nilai akhir Anda adalah A")
elif 70<= Nilai <=79:
    print("Nilai akhir Anda adalah B")
elif 60<= Nilai <=69:
    print("Nilai akhir Anda adalah C")
elif 50<= Nilai <=59:
    print("Nilai akhir Anda adalah D")
else:
    print("Nilai akhir Anda adalah E")