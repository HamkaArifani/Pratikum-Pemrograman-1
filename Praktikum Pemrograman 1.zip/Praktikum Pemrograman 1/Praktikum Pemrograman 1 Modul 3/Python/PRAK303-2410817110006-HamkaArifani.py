Bilangan=int(input("Masukkan bilangan = "))
if Bilangan==0:
    print("nol")
elif Bilangan<0:
    print("negatif")
else:
    print("positif")