input("Nama                 : ");
input("NIM                  : ");
input("Kelas Paralel        : ");
input("Tempat/Tanggal Lahir : ");
input("Alamat               : ");
input("Hobby                : ");
input("No.HP                : ");