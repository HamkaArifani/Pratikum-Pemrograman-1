Bil1=float(input("Masukkan nilai pertama : "));
Bil2=float(input("Masukkan nilai kedua : "));
Hasil=Bil1+Bil2;
print(f"Hasil penjumlahan dari nilai pertama \"{Bil1:.0f}\"  dan nilai kedua \"{Bil2:.1f}\" "
      f"adalah  \"{Hasil:.2f}\" ");